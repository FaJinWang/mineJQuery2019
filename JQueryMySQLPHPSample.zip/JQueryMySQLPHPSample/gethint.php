<?php

        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "color_test";

        $conn = mysqli_connect($servername, $username, $password,$dbname);
        $sql = "SELECT Votes FROM votes where Color = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $_GET['q']);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($Vote);
        $stmt->fetch();
        $stmt->close();
        echo "$Vote";
?>
