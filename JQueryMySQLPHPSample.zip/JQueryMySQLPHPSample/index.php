<!DOCTYPE HTML>
<html>
<head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script>
        function showcolor(str) {
            $.ajax({
                url: "gethint.php", data: {q: str}, success: function (result) {
                    $("." + str).html(result);
                }
            });
        }
        function showtotal() {

        }
        /*$.get("gethint.php", function(data, status){
            alert("Data: " + data + "\nStatus: " + status);
        });*/
            /*function showcolor(str) {
                $(".color").append("<td></td>");
            }*/

    </script>
</head>
<body>
<table>
    <tr>
        <td>Color</td>
        <td>Votes</td>
    </tr>
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "color_test";

        $conn = mysqli_connect($servername, $username, $password,$dbname);
        $sql = "SELECT * FROM colors";
        $result = mysqli_query($conn,$sql);
        while ($row = mysqli_fetch_assoc($result)){
            echo "<tr>";
            echo "<td><a href='#'><span onclick='showcolor(\"$row[Color]\")'>$row[Color]</span></a></td>";
            echo "<td class='$row[Color]'></td>";
            echo "</tr>";
        }
        ?>
</table>
</body>
</html>